# LaTeX2HTML 2K.1beta (1.47)
# Associate images original text with physical files.


$key = q/S_0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$S_0$">|; 

$key = q/includegraphics[width=4in]{fv_grid.eps};LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="458" HEIGHT="207" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics[width=4in]{fv_grid.eps}">|; 

$key = q/k=3;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img49.png"
 ALT="$k = 3$">|; 

$key = q/A;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="$A$">|; 

$key = q/langlefloatrangle;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="60" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img51.png"
 ALT="$\langle float \rangle$">|; 

$key = q/{displaymath}left[array{{ccc}&-1&-1&4&-1&-1&array{right].{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="352" HEIGHT="73" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\begin{displaymath}
\left [
\begin{array}{ccc}
&amp; -1 &amp; \\\\
-1 &amp; 4 &amp; -1 \\\\
&amp; -1 &amp;
\end{array}\right ] .
\end{displaymath}">|; 

$key = q/includegraphics[width=5in]{concep_iface.eps};LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="572" HEIGHT="316" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[width=5in]{concep_iface.eps}">|; 

$key = q/{displaymath}nablacdot(Dnablau)+sigmau=f{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="359" HEIGHT="31" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="\begin{displaymath}
\nabla \cdot ( D \nabla u ) + \sigma u = f
\end{displaymath}">|; 

$key = q/(0,-1);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="59" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="$(0,-1)$">|; 

$key = q/includegraphics[width=4in]{block_structured.eps};LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="458" HEIGHT="418" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="\includegraphics[width=4in]{block_structured.eps}">|; 

$key = q/10^{-7};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="22" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="$10 ^{-7}$">|; 

$key = q/{displaymath}left[array{{ccc}&(0,1)&&(0,0)&(1,0)&&array{right]equivleft[array{{ccc}&S_2&&S_0&S_1&&array{right].{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="422" HEIGHT="73" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\begin{displaymath}
\left [
\begin{array}{ccc}
&amp; ( 0, 1) &amp; \\\\
&amp; ( 0, 0) &amp; ( 1...
...ccc}
&amp; S_2 &amp; \\\\
&amp; S_0 &amp; S_1 \\\\
&amp; &amp;
\end{array}\right ] .
\end{displaymath}">|; 

$key = q/+1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="$+1$">|; 

$key = q/-{{tt{filter};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="75" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img44.png"
 ALT="$-{\tt filter}$">|; 

$key = q/m+1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img34.png"
 ALT="$m+1$">|; 

$key = q/{{tt{thresh}ge0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img37.png"
 ALT="${\tt thresh} \ge 0$">|; 

$key = q/k;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img48.png"
 ALT="$k$">|; 

$key = q/{displaymath}left[array{{ccc}(-1,1)&(0,1)&(1,1)(-1,0)&(0,0)&(1,0)(-1,-1)&(0,-1)&c}S_7&S_4&S_8S_1&S_0&S_2S_5&S_3&S_6array{right].{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="478" HEIGHT="73" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="\begin{displaymath}
\left [
\begin{array}{ccc}
(-1, 1) &amp; ( 0, 1) &amp; ( 1, 1) \\\\
(...
... \\\\
S_1 &amp; S_0 &amp; S_2 \\\\
S_5 &amp; S_3 &amp; S_6
\end{array}\right ] .
\end{displaymath}">|; 

$key = q/{{tt{thresh}=-0.9;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="120" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img43.png"
 ALT="${\tt thresh} = -0.9$">|; 

$key = q/{{tt{filter}<0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img41.png"
 ALT="${\tt filter} &lt; 0$">|; 

$key = q/LU;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img54.png"
 ALT="$ L U$">|; 

$key = q/|b~-~Ax^{(n)}|_2slash|b|_2leq;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="174" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$\Vert b &nbsp; - &nbsp; Ax^{(n)} \Vert _2 / \Vert b \Vert _2 \leq $">|; 

$key = q/{{it{nlevels}=1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="90" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="${\it nlevels} = 1$">|; 

$key = q/U;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img57.png"
 ALT="$U$">|; 

$key = q/-a_{i,j}geqthetamax_{jneqi}-a_{ij};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="158" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="$-a_{i,j} \geq \theta
\max_{j \neq i} \-a_{ij}$">|; 

$key = q/-{{tt{thresh};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="75" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img42.png"
 ALT="$-{\tt thresh}$">|; 

$key = q/{displaymath}left{array{{ll}nabla^2u=f,&mbox{inthedomain},u=0,&mbox{ontheboundary}.array{right.{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="395" HEIGHT="54" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\begin{displaymath}
\left \{
\begin{array}{ll}
\nabla^2 u = f , &amp; \mbox{in the domain}, \\\\
u = 0, &amp; \mbox{on the boundary}.
\end{array}\right .
\end{displaymath}">|; 

$key = q/{displaymath}left[array{{ccc}&(0,1)&(-1,0)&(0,0)&(1,0)&(0,-1)&array{right]equivlft[array{{ccc}&S_4&S_1&S_0&S_2&S_3&array{right].{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="73" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="\begin{displaymath}
\left [
\begin{array}{ccc}
&amp; ( 0, 1) &amp; \\\\
(-1, 0) &amp; ( 0, 0...
... S_4 &amp; \\\\
S_1 &amp; S_0 &amp; S_2 \\\\
&amp; S_3 &amp;
\end{array}\right ] .
\end{displaymath}">|; 

$key = q/{{tt{filter}=-0.9;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="120" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img45.png"
 ALT="${\tt filter} = -0.9$">|; 

$key = q/theta;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="$\theta$">|; 

$key = q/{displaymath}left[array{{c}~~~~~~~~~~A_0~~~~~~~~~~A_1vdotsA_{P-1}array{right]{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="364" HEIGHT="102" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="\begin{displaymath}
\left[
\begin{array}{c}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; A_0 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; \\\\
A_1 \\\\
\vdots \\\\
A_{P-1}
\end{array}\right]
\end{displaymath}">|; 

$key = q/langleintrangle;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img50.png"
 ALT="$\langle int \rangle$">|; 

$key = q/L;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img56.png"
 ALT="$L$">|; 

$key = q/0le{{it{thresh}le1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="117" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="$0 \le {\it thresh} \le 1$">|; 

$key = q/i;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="$i$">|; 

$key = q/(A+A^T)slash2;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="95" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img47.png"
 ALT="$(A+A^T)/2$">|; 

$key = q/{{tt{filter}ge0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img40.png"
 ALT="${\tt filter} \ge 0$">|; 

$key = q/F;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img53.png"
 ALT="$F$">|; 

$key = q/0le{{it{nlevels};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="90" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="$0 \le {\it nlevels}$">|; 

$key = q/m={{tt{nlevel}+1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="130" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img36.png"
 ALT="$m={\tt nlevel}+1$">|; 

$key = q/{{tt{nlevel}ge0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img35.png"
 ALT="${\tt nlevel} \ge 0$">|; 

$key = q/{{tt{thresh}<0;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img39.png"
 ALT="${\tt thresh} &lt; 0$">|; 

$key = q/tilde{A}^m;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="23" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="$\tilde{A}^m$">|; 

$key = q/0,1,...,P-1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="105" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$0, 1, ..., P-1$">|; 

$key = q/{displaymath}left[array{{ccc}-1&-1&-1-1&8&-1-1&-1&-1array{right].{displaymath};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="352" HEIGHT="73" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="\begin{displaymath}
\left [
\begin{array}{ccc}
-1 &amp; -1 &amp; -1 \\\\
-1 &amp; 8 &amp; -1 \\\\
-1 &amp; -1 &amp; -1
\end{array}\right ] .
\end{displaymath}">|; 

$key = q/P;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="$P$">|; 

$key = q/(0,0);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$(0,0)$">|; 

$key = q/=;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img38.png"
 ALT="$=$">|; 

$key = q/M;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img46.png"
 ALT="$M$">|; 

$key = q/{{it{thresh}=0.1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="98" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="${\it thresh} = 0.1$">|; 

$key = q/-1;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="$-1$">|; 

$key = q/A_p;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="$A_p$">|; 

$key = q/tilde{A};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="23" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img33.png"
 ALT="$\tilde{A}$">|; 

$key = q/j;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="$j$">|; 

$key = q/F=L+U-I;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="121" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img52.png"
 ALT="$F = L+U-I$">|; 

$key = q/S_3;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="$S_3$">|; 

$key = q/M=LU;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img55.png"
 ALT="$ M = L U $">|; 

1;

