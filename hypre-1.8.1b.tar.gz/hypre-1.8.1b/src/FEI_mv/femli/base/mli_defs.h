/*BHEADER**********************************************************************
 * (c) 2001   The Regents of the University of California
 *
 * See the file COPYRIGHT_and_DISCLAIMER for a complete copyright
 * notice, contact person, and disclaimer.
 *
 *********************************************************************EHEADER*/

/******************************************************************************
 *
 * global definitions
 *
 *****************************************************************************/

#ifndef __MLIDEFS__
#define __MLIDEFS__

#define   MLI_FALSE                      0
#define   MLI_TRUE                       1
#define   MLI_NONE                      -1
#define   MLI_DEFAULT                   -1
 
#define   MLI_SMOOTHER_PRE               1
#define   MLI_SMOOTHER_POST              2
#define   MLI_SMOOTHER_BOTH              3

#endif

